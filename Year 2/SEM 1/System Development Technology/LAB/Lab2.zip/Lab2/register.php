<!DOCTYPE html>
<html>
<head>
    <title>Student Information Registration Page</title>
    <style>
        h1 {
            color: black;
            text-align: center;
            padding: 15px;
            font-size: 40px;
        }

        p {
            background-color: yellow;
            color: black;
            text-align: center;
            font-size: 25px;
            margin: 10px 0; 
            padding: 12px; 
            margin-bottom: 30px;
        }

        body {
            border: 3px solid black;
            margin: 50px auto;
            font-family: 'Times New Roman', Times, serif;
            width: 25%;
            padding: 20px;
            height: 1050px;
            font-size: 22px;
        }

        input[type="text"],
        input[type="email"],
        input[type="date"],
        select,
        button {
            width: 100%; 
            padding: 10px; 
            margin-bottom: 30px;
            margin-top: 15px;
            font-size: 17px;
            box-sizing: border-box;
        }

        button {
            background-color: chartreuse; 
            color: black; 
            font-weight: bold; 
        }

        a {
            text-align: center; 
            display: block; 
            margin-top: 10px;
            color: indigo; 
            text-decoration: underline; 
        }
    </style>
</head>
<body>
    <h1><b>New Student Registration Form</b></h1>

    <form action="register.php" method="POST">
        <p><b>Student Personal Details:</b></p>

        <label><b>Full Name:</b></label>
        <input type="text" name="name" required><br>

        <label><b>Email:</b></label>
        <input type="email" name="email" required><br>
        
        <label><b>Gender:</b></label>
        <div style='text-align: center;'>
            <input type="radio" name="gender" value="Male" required>
            <label for="male">Male</label>
            <input type="radio" name="gender" value="Female" required>
            <label for="female">Female</label><br>
        </div>

        <label><b>Date of Birth:</b></label>
        <input type="date" id="birthday" name="birthday" required><br>

        <p><b>Academic Information:</b></p>
        <label for="programs"><b>Program of Study:</b></label>
        <select name="program" id="program" required>
            <option value="">Please Select</option>
            <option value="Data Engineering">Data Engineering</option>
            <option value="Software Engineering">Software Engineering</option>
            <option value="Graphic Design and Multimedia">Graphic Design and Multimedia</option>
            <option value="Bioinformatics">Bioinformatics</option>
            <option value="Network and Security">Network and Security</option>
        </select>
        
        <button type="submit">Add Student</button>
    </form>
    <a href="view.php">Back to User List</a>

    <?php
    include 'db.php'; 

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $gender = $_POST['gender'];
        $birthday = $_POST['birthday'];
        $program = $_POST['program'];

        $stmt = $conn->prepare("INSERT INTO users (name, email, gender, birthday, program) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $name, $email, $gender, $birthday, $program);

        if ($stmt->execute()) {
            echo "<div style='text-align: center; margin-top: 20px;'>New record created successfully</div>";
        } else {
            echo "<div style='color: red; text-align: center; margin-top: 20px;'>Error: " . $stmt->error . "</div>";
        }

        $stmt->close();
    }

    ?>

</body>
</html>
