<html>
<head>
    <title>Registered Students</title>
    <style>
        body {
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            background-color: aliceblue;  
            margin: 0;
            padding: 50px;  
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            color: black;
            margin-top: 20px;
            font-size: 40px;
            text-align: center;
        }

        table {
            border: 1px solid black;  
            width: 80%;
            margin-top: 20px;
            background-color: white;
        }

        th, td {
            padding: 12px;
            text-align: center;
            border: 2px solid black;  
        }

        th {
            background-color: gold;
            color: black;
        }

        a {
            color: green;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h2>List of Faculty Computing Year 1 Registered Students</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Gender</th>
            <th>Birthday</th>
            <th>Program</th>
            <th>Update</th>
            <th>Delete</th>
        </tr>
        
        <?php
        include "db.php"; 

        $sql = "SELECT * FROM users";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) { 
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                echo "<td>" . htmlspecialchars($row['gender']) . "</td>";
                echo "<td>" . htmlspecialchars($row['birthday']) . "</td>";
                echo "<td>" . htmlspecialchars($row['program']) . "</td>";
                echo "<td> <a href='update.php?id=" . htmlspecialchars($row['id']) . "'>Update</a> </td>";
                echo "<td> <a href='delete.php?id=" . htmlspecialchars($row['id']) . "'>Delete</a> </td>";
               echo "</tr>";
           }
       }else {
          echo "<tr><td colspan='8'>No Data Found</td></tr>";
        }

        mysqli_stmt_close($stmt);
        ?>

    </table>
    <br>
    <a href="register.php">Add New User</a>
</body>
</html>

