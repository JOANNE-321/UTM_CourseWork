<html>
<head>
    <title>Update User</title>
    <style>
    body {
        font-family: Verdana, Geneva, Tahoma, sans-serif;
        background-color: white;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .container {
        background-color: aliceblue;
        padding: 30px;
        border-radius: 8px;
        border: 3px solid black;
        width: 400px;
        text-align: left;
    }

    h2 {
        color: black;
        font-size: xx-large;
        text-align: center;
        margin-bottom: 30px;
    }

    form {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    label {
        font-weight: bold;
        color: black;
        font-size: large;
    }

    input[type="text"], 
    input[type="email"], 
    input[type="date"], 
    input[type="program"], 
    select {
        padding: 8px;
        border: 2px solid black;
        border-radius: 4px;
        width: 100%;
        font-size: large;
    }

    button {
        background-color: yellow;
        color: black;
        border: 1px solid #333;
        padding: 10px;
        font-weight: bold;
        font-size: large;
        border-radius: 4px;
        cursor: pointer;
        text-align: center;
        width: 100%;
    }

    a {
        color: indigo;
        text-decoration: underline;
        display: block;
        text-align: center;
        margin-top: 15px;
        font-size: large;
    }
    </style>
</head>
<body>
    <div class="container">
        <h2>Update Information</h2>

        <?php
        include "db.php"; 
        
        if (isset($_GET['id'])) {
            $id = $_GET['id']; 
            $sql = "SELECT * FROM users WHERE id=?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "i", $id); // 'i' for integer
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $row = mysqli_fetch_assoc($result);
        }

        ?>

        <form action="update.php?id=<?php echo $row['id']; ?>" method="POST">
            <label>Name:</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" required>

            <label>Email:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" required>

            <label>Gender:</label>
            <input type="text" name="gender" value="<?php echo htmlspecialchars($row['gender']); ?>" required>

            <label>Birthday:</label>
            <input type="date" name="birthday" value="<?php echo htmlspecialchars($row['birthday']); ?>" required>

            <label>Program:</label>
            <input type="text" name="program" value="<?php echo htmlspecialchars($row['program']); ?>" required>

            <button type="submit">Update User</button>
            <a href="view.php">Back to User List</a>
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
           
            $name = $_POST['name'];
            $email = $_POST['email'];
            $gender = $_POST['gender'];
            $birthday = $_POST['birthday'];
            $program = $_POST['program'];

            
            $sql = "UPDATE users SET name=?, email=?, gender=?, birthday=?, program=? WHERE id=?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "sssssi", $name, $email, $gender, $birthday, $program, $id); // 's' for string, 'i' for integer

            if (mysqli_stmt_execute($stmt)) {
                echo "<div style='text-align: center;'>Record updated successfully</div>";
            } else {
                echo "<div style='text-align: center;'>Error: " . mysqli_error($conn) . "</div>";
            }

            mysqli_stmt_close($stmt);
        }
        ?>
    </div>
</body>
</html>
