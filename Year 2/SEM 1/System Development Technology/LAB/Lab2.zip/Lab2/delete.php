<?php
include "db.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    if (isset($_POST['confirm'])) {
        // Prepare an SQL statement for deletion
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $id); // "i" specifies the variable type => integer

        // Execute the prepared statement
        if ($stmt->execute()) {
            echo "<script>alert('User Deleted Successfully');window.location='view.php'</script>";
        } else {
            echo "<script>alert('User Not Deleted');window.location='view.php'</script>";
        }

        // Close the statement
        $stmt->close();
    } elseif (isset($_POST['cancel'])) {
        header("Location: view.php");
        exit();
    }
} else {
    header("Location: view.php"); 
    exit();
}
?>


<html>
<head>
    <title>Confirm Deletion</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color:white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
           
        }

        .confirmation-container {
            background-color:azure;
            padding: 20px;
            border: 1px solid black;
            border-radius: 5px;
            text-align: center;
            width: 400px;
        }

        h2 {
            font-size: 18px;
            color: #333;
            margin-bottom: 15px;
        }

        .confirmation-buttons button {
            padding: 12px ;
            margin: 10px;
            border: black;
            border-radius: 3px;

        }

        .confirm-btn {
            background-color: red;
            color: white;
        }

        .cancel-btn {
            background-color: green;
            color: white;
        }
    </style>
</head>
<body>
    <div class="confirmation-container">
        <h2>Are you sure you want to delete this student?</h2>
        <form method="POST" action="">
            <div class="confirmation-buttons">
                <button type="submit" name="confirm" class="confirm-btn">Yes, Delete</button>
                <button type="submit" name="cancel" class="cancel-btn">No, Cancel</button>
            </div>
        </form>
    </div>
</body>
</html>